import streamlit as st
import tensorflow as tf
from tensorflow.keras.preprocessing.image import img_to_array
from PIL import Image
import numpy as np
import pickle
import os

# CONFIG
IMG_SIZE = (224, 224)
MODEL_FILE = "fixed_model.h5"
THRESH_FILE = "best_threshold.pkl"


@st.cache_resource
def load_artifacts():
    if not os.path.exists(MODEL_FILE):
        return None, None, 0.5
    try:
        model = tf.keras.models.load_model(MODEL_FILE, compile=False)
        with open(THRESH_FILE, "rb") as f:
            thresh = pickle.load(f)

        # Safety: if threshold invalid, fall back to 0.5
        if not isinstance(thresh, (int, float)) or np.isnan(thresh) or np.isinf(thresh):
            auto_thresh_display = 0.5
        else:
            auto_thresh_display = float(thresh)

        return model, thresh, auto_thresh_display
    except Exception as e:
        st.error(f"Error loading model artifacts: {e}")
        return None, None, 0.5


def process_img(img_file):
    img = Image.open(img_file).convert("RGB").resize(IMG_SIZE)
    arr = img_to_array(img) / 255.0
    return np.expand_dims(arr, axis=0), img


st.set_page_config(page_title="Spam Image Detector", layout="wide")

st.title("🛑 Spam SMS / Email Image Detector")

model, actual_auto_thresh, auto_thresh_display = load_artifacts()

if model is None:
    st.warning("Model or threshold file not found. Please run the training script first.")
    st.stop()

# Sidebar controls
st.sidebar.header("⚙ Sensitivity Control")
st.sidebar.info(f"Auto-calculated threshold: **{auto_thresh_display:.3f}**")
user_thresh = st.sidebar.slider("Manual Threshold Override", 0.0, 1.0, float(auto_thresh_display))

uploaded = st.file_uploader("Upload an image of SMS/Email", type=["png", "jpg", "jpeg"])

if uploaded is not None:
    data, view_img = process_img(uploaded)

    # Predict probability of spam
    prob = float(model.predict(data, verbose=0)[0][0])

    col1, col2 = st.columns(2)
    with col1:
        st.image(view_img, caption="Uploaded Image", use_column_width=True)
    with col2:
        st.metric(label="Spam Probability (P(spam))", value=f"{prob:.4f}")
        if prob >= user_thresh:
            st.error("🔴 Classified as **SPAM**")
            confidence = prob
        else:
            st.success("🟢 Classified as **HAM**")
            confidence = 1.0 - prob

        st.metric(label="Confidence", value=f"{confidence * 100:.2f}%")
        st.markdown(
            f"<div style='font-size:14px; color:gray;'>"
            f"Decision rule: classified as SPAM if P(spam) ≥ {user_thresh:.3f}"
            f"</div>",
            unsafe_allow_html=True,
        )
else:
    st.info("Please upload an image to get a prediction.")
