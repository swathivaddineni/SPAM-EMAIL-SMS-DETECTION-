# 📩 Spam SMS & Email Image Detection using Deep Learning

A complete end-to-end pipeline that detects **spam vs ham** messages from **images** using:
- EfficientNetB0 Transfer Learning
- Automatic Dataset Downloading & Cleaning
- ROC-AUC Based Threshold Optimization
- Streamlit Web App
- Optional Dummy Dataset Generator for Testing

---

## 🚀 Features

- 🔽 Automatic dataset download from the JHU Image Spam dataset
- 🧹 Ultra-cleaning of images (removes corrupt / weird formats and converts everything to clean JPG)
- 🧠 Transfer learning with EfficientNetB0
- ⚖️ Automatic best-threshold selection using ROC curve
- 🌐 Streamlit app for interactive spam/ham prediction
- 🧪 Optional dummy dataset generator for quick testing

---

## 📁 Project Structure

```text
spam-email-sms-detection/
│
├── README.md
├── requirements.txt
├── .gitignore
│
├── train_pipeline/
│   └── train_full_pipeline.py
│
├── streamlit_app/
│   └── app.py
│
└── dummy_dataset/
    └── generate_dummy_data.py
```

---

## 🔧 Installation

```bash
git clone https://github.com/<your-username>/spam-email-sms-detection.git
cd spam-email-sms-detection
pip install -r requirements.txt
```

---

## 🏋️ Train the Model (Real Dataset)

Run the full training pipeline (downloads and cleans the JHU spam image dataset, trains EfficientNetB0, selects best threshold, and saves artifacts):

```bash
python train_pipeline/train_full_pipeline.py
```

This will create:

- `streamlit_app/fixed_model.h5`
- `streamlit_app/best_threshold.pkl`

---

## 🌐 Run the Streamlit App

From the project root:

```bash
streamlit run streamlit_app/app.py
```

Upload an image of an SMS/Email.  
The app will show:

- Probability that the image is **spam**
- Decision (SPAM / HAM)
- Confidence
- Threshold used for decision

---

## 🧪 Dummy Dataset (Optional)

If you just want to test the flow without downloading the big dataset, you can generate a tiny dummy dataset of red/green images:

```bash
python dummy_dataset/generate_dummy_data.py
```

That script will create a folder `dummy_dataset/ham` and `dummy_dataset/spam` with simple colored images you can use to test loading / visualization logic.

---

## 💡 Threshold Logic

By default, the model outputs a probability `P(spam)` between 0 and 1.

- If **P(spam) ≥ threshold → SPAM**
- Else → HAM

The training pipeline computes the **best threshold** using the ROC curve and stores it in `best_threshold.pkl`.  
The Streamlit app allows you to override this threshold manually from the sidebar.

---

## 👩‍💻 Author

Project prepared for academic purposes by **Swathi Vaddineni**.

