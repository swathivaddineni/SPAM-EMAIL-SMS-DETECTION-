import os
import shutil
from PIL import Image

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DUMMY_DATASET_DIR = os.path.join(BASE_DIR, "dummy_dataset")
NUM_HAM_IMAGES = 100
NUM_SPAM_IMAGES = 100
IMG_SIZE = (224, 224)


def create_dummy_image(filepath, color, size=IMG_SIZE):
    """Creates a simple solid-color square image."""
    img = Image.new("RGB", size, color)
    img.save(filepath)


def main():
    if os.path.exists(DUMMY_DATASET_DIR):
        shutil.rmtree(DUMMY_DATASET_DIR)

    ham_dir = os.path.join(DUMMY_DATASET_DIR, "ham")
    spam_dir = os.path.join(DUMMY_DATASET_DIR, "spam")
    os.makedirs(ham_dir, exist_ok=True)
    os.makedirs(spam_dir, exist_ok=True)

    print(f"Creating {NUM_HAM_IMAGES} dummy 'ham' images...")
    for i in range(NUM_HAM_IMAGES):
        create_dummy_image(os.path.join(ham_dir, f"ham_{i}.png"), (0, 150, 0))  # Green

    print(f"Creating {NUM_SPAM_IMAGES} dummy 'spam' images...")
    for i in range(NUM_SPAM_IMAGES):
        create_dummy_image(os.path.join(spam_dir, f"spam_{i}.png"), (150, 0, 0))  # Red

    print(f"✅ Dummy dataset created at {DUMMY_DATASET_DIR}")


if __name__ == '__main__':
    main()
