import os
import shutil
import tarfile
import pickle
import numpy as np
import tensorflow as tf
from tensorflow.keras import layers, models, applications
from sklearn.metrics import roc_curve
from tensorflow.keras.preprocessing import image_dataset_from_directory
from PIL import Image

# ------------------------------------------------------------------
# CONFIG
# ------------------------------------------------------------------
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATASET_DIR = os.path.join(BASE_DIR, "dataset")
IMG_SIZE = (224, 224)
BATCH_SIZE = 32

SPAM_URL = "https://www.cs.jhu.edu/~mdredze/datasets/image_spam/personal_image_spam.tar.gz"
HAM_URL = "https://www.cs.jhu.edu/~mdredze/datasets/image_spam/personal_image_ham.tar.gz"
SPAM_TAR = os.path.join(BASE_DIR, "personal_image_spam.tar.gz")
HAM_TAR = os.path.join(BASE_DIR, "personal_image_ham.tar.gz")

APP_DIR = os.path.join(BASE_DIR, "streamlit_app")
os.makedirs(APP_DIR, exist_ok=True)
MODEL_PATH = os.path.join(APP_DIR, "fixed_model.h5")
THRESH_PATH = os.path.join(APP_DIR, "best_threshold.pkl")

# ------------------------------------------------------------------
# HELPERS
# ------------------------------------------------------------------

def download_dataset():
    import urllib.request

    print("⬇️ Downloading datasets (if needed)...")

    for url, dst in [(SPAM_URL, SPAM_TAR), (HAM_URL, HAM_TAR)]:
        if not os.path.exists(dst):
            print(f"   -> Downloading {os.path.basename(dst)}")
            urllib.request.urlretrieve(url, dst)
        else:
            print(f"   -> Found existing {os.path.basename(dst)}, skipping download.")

def extract_and_flatten(tar_path, label):
    print(f"📂 Extracting {os.path.basename(tar_path)} for label '{label}'...")
    # Extract into DATASET_DIR
    try:
        with tarfile.open(tar_path, "r:gz") as t:
            t.extractall(DATASET_DIR, filter='data')
    except TypeError:
        # For older Python/tarfile versions without 'filter'
        with tarfile.open(tar_path, "r:gz") as t:
            t.extractall(DATASET_DIR)

    final_folder = os.path.join(DATASET_DIR, label)
    os.makedirs(final_folder, exist_ok=True)

    # Walk through extracted folders and move matching images into final_folder
    for root, dirs, files in os.walk(DATASET_DIR):
        if label in os.path.basename(root) and root != final_folder:
            for f in files:
                if f.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.bmp')):
                    src = os.path.join(root, f)
                    dst = os.path.join(final_folder, f)
                    if src == dst:
                        continue
                    try:
                        shutil.move(src, dst)
                    except Exception:
                        pass

def clean_extra_folders():
    # Keep only DATASET_DIR/ham and DATASET_DIR/spam
    for f in os.listdir(DATASET_DIR):
        if f not in ["ham", "spam"]:
            path = os.path.join(DATASET_DIR, f)
            if os.path.isdir(path):
                print(f"   -> Removing extra folder: {path}")
                shutil.rmtree(path, ignore_errors=True)

def ultra_clean_and_convert(dir_path):
    print("\n🔥 ULTRA CLEANING: verifying and converting ALL files to clean JPGs...")
    removed = 0
    validated = 0

    for root, dirs, files in os.walk(dir_path, topdown=False):
        for file in files:
            file_path = os.path.join(root, file)

            # Remove invisible / non-image / weird extensions
            if file.startswith('.') or not file.lower().endswith(('.jpg', '.jpeg', '.png', '.gif', '.bmp')):
                try:
                    os.remove(file_path)
                    removed += 1
                except Exception:
                    pass
                continue

            temp_path = file_path + ".temp.jpg"

            try:
                with Image.open(file_path) as img:
                    rgb_im = img.convert("RGB")
                    rgb_im.save(temp_path, "JPEG")

                os.remove(file_path)
                shutil.move(temp_path, file_path)
                validated += 1

            except Exception:
                # If anything goes wrong, delete the file
                try:
                    os.remove(file_path)
                except Exception:
                    pass
                if os.path.exists(temp_path):
                    os.remove(temp_path)
                removed += 1

    print("✅ ULTRA CLEANUP COMPLETE:")
    print(f"   - Total files validated & converted: {validated}")
    print(f"   - Total files deleted (corrupt/invalid): {removed}")

# ------------------------------------------------------------------
# MAIN TRAINING PIPELINE
# ------------------------------------------------------------------

def main():
    # Fresh dataset folder
    if os.path.exists(DATASET_DIR):
        shutil.rmtree(DATASET_DIR)
    os.makedirs(DATASET_DIR, exist_ok=True)

    # 1) Download
    download_dataset()

    # 2) Extract & flatten
    extract_and_flatten(SPAM_TAR, "spam")
    extract_and_flatten(HAM_TAR, "ham")
    clean_extra_folders()

    spam_count = len(os.listdir(os.path.join(DATASET_DIR, "spam")))
    ham_count = len(os.listdir(os.path.join(DATASET_DIR, "ham")))
    print("✅ Data Extraction Complete.")
    print(f"   SPAM images initial count: {spam_count}")
    print(f"   HAM  images initial count: {ham_count}")

    # 3) Ultra clean & convert
    ultra_clean_and_convert(DATASET_DIR)

    # 4) Build datasets
    print("\n🔄 Loading sanitized dataset for training...")

    train_ds = image_dataset_from_directory(
        DATASET_DIR,
        validation_split=0.2,
        subset="training",
        seed=123,
        image_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        label_mode="binary",
        class_names=["ham", "spam"],
    )

    val_ds = image_dataset_from_directory(
        DATASET_DIR,
        validation_split=0.2,
        subset="validation",
        seed=123,
        image_size=IMG_SIZE,
        batch_size=BATCH_SIZE,
        label_mode="binary",
        class_names=["ham", "spam"],
    )

    norm_layer = layers.Rescaling(1.0 / 255)
    train_ds = train_ds.map(lambda x, y: (norm_layer(x), y)).cache().prefetch(tf.data.AUTOTUNE)
    val_ds = val_ds.map(lambda x, y: (norm_layer(x), y)).cache().prefetch(tf.data.AUTOTUNE)

    # 5) Build model (EfficientNetB0)
    print("\n🧠 Building EfficientNetB0 model...")

    base_model = applications.EfficientNetB0(
        include_top=False,
        input_shape=IMG_SIZE + (3,),
        weights="imagenet",
    )
    base_model.trainable = False

    model = models.Sequential(
        [
            base_model,
            layers.GlobalAveragePooling2D(),
            layers.Dropout(0.2),
            layers.Dense(1, activation="sigmoid"),
        ]
    )

    model.compile(optimizer="adam", loss="binary_crossentropy", metrics=["accuracy"])

    print("\n🚀 Starting training...")
    model.fit(train_ds, validation_data=val_ds, epochs=5)

    # 6) Threshold selection
    print("\n⚖️ Calculating best threshold and saving artifacts...")
    y_true = np.concatenate([y for x, y in val_ds], axis=0)
    y_pred = model.predict(val_ds).ravel()

    fpr, tpr, thresholds = roc_curve(y_true, y_pred)
    best_idx = np.argmax(tpr - fpr)
    best_thresh = float(thresholds[best_idx])

    print(f"✅ Optimal Threshold Found: {best_thresh:.4f}")

    # 7) Save model + threshold into streamlit_app/
    model.save(MODEL_PATH)
    with open(THRESH_PATH, "wb") as f:
        pickle.dump(best_thresh, f)

    print("\n🎉 DONE!")
    print(f"   - Model saved to: {MODEL_PATH}")
    print(f"   - Threshold saved to: {THRESH_PATH}")


if __name__ == '__main__':
    main()
